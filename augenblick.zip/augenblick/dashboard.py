# # # # import streamlit as st
# # # # import pandas as pd
# # # # import plotly.graph_objects as go
# # # # import pickle
# # # # import matplotlib.pyplot as plt
# # # # from sklearn.metrics import classification_report
# # # # from sklearn.ensemble import IsolationForest
# # # # from sklearn.model_selection import train_test_split
# # # # from sklearn.preprocessing import StandardScaler
# # # # import seaborn as sns

# # # # # Load the dataset
# # # # df = pd.read_csv('data/Combined_Dataset.csv')

# # # # # Display the first few rows of the dataset in the app
# # # # st.title("Anomaly Detection and Prediction Dashboard")
# # # # st.write("Dataset Overview")
# # # # st.write(df.head())

# # # # # Prepare the data for the model
# # # # sensor_columns = ['Air temperature [K]', 'Process temperature [K]', 'Rotational speed [rpm]', 'Torque [Nm]']
# # # # X = df[sensor_columns]
# # # # y = df['Machine failure']  # Assuming 'Machine failure' is the target variable

# # # # # Split the dataset into training and testing sets
# # # # X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# # # # # Normalize the data
# # # # scaler = StandardScaler()
# # # # X_train_scaled = scaler.fit_transform(X_train)
# # # # X_test_scaled = scaler.transform(X_test)

# # # # # Train an Isolation Forest model
# # # # model = IsolationForest(n_estimators=100, contamination=0.1, random_state=42)
# # # # model.fit(X_train_scaled)

# # # # # Predict anomalies in the test data
# # # # y_pred = model.predict(X_test_scaled)
# # # # y_pred = [1 if pred == 1 else 0 for pred in y_pred]  # Convert to binary labels (1 for normal, 0 for anomaly)

# # # # # Generate and display classification report
# # # # st.subheader("Model Performance (Classification Report)")
# # # # report = classification_report(y_test, y_pred, output_dict=True)
# # # # report_df = pd.DataFrame(report).transpose()
# # # # st.write(report_df)

# # # # # Display confusion matrix using Plotly
# # # # st.subheader("Confusion Matrix")
# # # # confusion_matrix = pd.crosstab(y_test, y_pred, rownames=['Actual'], colnames=['Predicted'])
# # # # fig = go.Figure(data=[
# # # #     go.Heatmap(
# # # #         z=confusion_matrix.values,
# # # #         x=confusion_matrix.columns,
# # # #         y=confusion_matrix.index,
# # # #         colorscale='Viridis',
# # # #         zmid=0,
# # # #     )
# # # # ])
# # # # fig.update_layout(title="Confusion Matrix", xaxis_title="Predicted", yaxis_title="Actual")
# # # # st.plotly_chart(fig)

# # # # # Anomalies over time visualization (Matplotlib Plot)
# # # # st.subheader("Anomalies Over Time (Matplotlib Plot)")
# # # # # Add a 'timestamp' column for plotting over time
# # # # df['timestamp'] = pd.to_datetime(df['timestamp'])
# # # # # Assuming your data is loaded in df and y_pred is the anomaly prediction result
# # # # print(len(df), len(y_pred))  # Check lengths to debug

# # # # # Check if the lengths match
# # # # if len(df) != len(y_pred):
# # # #     # Assuming sensor_columns are correctly selected for prediction
# # # #     y_pred = model.predict(df[sensor_columns])  # Ensure correct subset for prediction

# # # # # Now assign anomaly prediction to the DataFrame
# # # # df['anomaly'] = y_pred  # This should now work since lengths match


# # # # # Plot anomalies over time
# # # # plt.figure(figsize=(10, 6))
# # # # sns.scatterplot(x=df['timestamp'], y=df['Machine failure'], hue=df['anomaly'], palette="coolwarm", s=60)
# # # # plt.title('Anomalies Over Time')
# # # # plt.xlabel('Timestamp')
# # # # plt.ylabel('Machine Failure')
# # # # st.pyplot(plt)

# # # import streamlit as st
# # # import pandas as pd
# # # import pickle
# # # import xgboost as xgb
# # # import plotly.graph_objects as go

# # # # Function to load the XGBoost model
# # # @st.cache_data
# # # def load_model():
# # #     with open('saved_model/xgboost_model.pkl', 'rb') as f:
# # #         model = pickle.load(f)
# # #     return model

# # # # Load the XGBoost model
# # # model = load_model()

# # # # Function to preprocess the dataset
# # # def preprocess_data(df):
# # #     # Modify this preprocessing as per your dataset and requirements
# # #     df['hour'] = pd.to_datetime(df['timestamp']).dt.hour
# # #     df['day_of_week'] = pd.to_datetime(df['timestamp']).dt.dayofweek
# # #     sensor_columns = ['Air temperature [K]', 'Process temperature [K]', 'Rotational speed [rpm]', 'Torque [Nm]']
# # #     df['Rolling_Mean_Temperature'] = df['Air temperature [K]'].rolling(window=3).mean()
# # #     df['Rolling_Std_Temperature'] = df['Air temperature [K]'].rolling(window=3).std()
# # #     df['Lag_1_Temperature'] = df['Air temperature [K]'].shift(1)
# # #     df['Lag_2_Temperature'] = df['Air temperature [K]'].shift(2)

# # #     # Drop rows with NaN values in the necessary columns
# # #     df = df.dropna(subset=sensor_columns + ['Rolling_Mean_Temperature', 'Rolling_Std_Temperature', 'Lag_1_Temperature', 'Lag_2_Temperature'])
    
# # #     return df, sensor_columns

# # # # Function to predict anomalies using XGBoost
# # # def predict_anomalies(df, model, sensor_columns):
# # #     # Prepare features for anomaly detection
# # #     X = df[sensor_columns + ['Rolling_Mean_Temperature', 'Rolling_Std_Temperature', 'Lag_1_Temperature', 'Lag_2_Temperature']]
# # #     predictions = model.predict(X)
# # #     return predictions

# # # # Load dataset
# # # df = pd.read_csv('data/Combined_Dataset.csv')

# # # # Preprocess the data
# # # df, sensor_columns = preprocess_data(df)

# # # # Predict anomalies using the XGBoost model
# # # y_pred = predict_anomalies(df, model, sensor_columns)

# # # # Add predictions to the dataframe
# # # df['anomaly'] = y_pred

# # # # Display the dashboard
# # # st.title('Anomaly Detection and Prediction Dashboard')

# # # # Dataset Overview
# # # st.write('### Dataset Overview:')
# # # st.dataframe(df.head())  # Display the first few rows of the dataframe

# # # # Model Performance (Classification Report)
# # # st.subheader('Model Performance (Classification Report)')
# # # # Assuming you have a classification report from your model. Update this part accordingly.
# # # # Here, I'm assuming the model's accuracy, precision, recall, and F1-Score for demonstration.
# # # st.text("""
# # #     Accuracy: 0.88
# # #     Precision: 0.90
# # #     Recall: 0.70
# # #     F1-Score: 0.79
# # # """)

# # # # Plot anomalies over time using Plotly
# # # st.subheader('Anomalies Over Time (Plotly Graph)')

# # # # Create the plot
# # # fig = go.Figure()
# # # fig.add_trace(go.Scatter(x=df['timestamp'], y=df['anomaly'], mode='markers', name='Anomaly'))
# # # fig.update_layout(title='Anomalies Over Time', xaxis_title='Timestamp', yaxis_title='Anomaly', showlegend=True)

# # # # Display the plot
# # # st.plotly_chart(fig)

# # # # Sensor Data Analysis (Plot temperature trends)
# # # st.subheader('Sensor Data Analysis (Temperature Trends)')
# # # fig_temp = go.Figure()

# # # # Add trace for 'Air temperature [K]' sensor readings
# # # fig_temp.add_trace(go.Scatter(x=df['timestamp'], y=df['Air temperature [K]'], mode='lines', name='Air Temperature [K]'))

# # # # Display the temperature trend plot
# # # st.plotly_chart(fig_temp)

# # # # Anomaly Prediction Results (Show anomalies in a table)
# # # st.subheader('Anomaly Prediction Results')
# # # st.write('### Anomaly Prediction Table:')
# # # st.dataframe(df[['timestamp', 'Air temperature [K]', 'anomaly']])

# # # # Optional: Feature Importance (if available from the model)
# # # st.subheader('Feature Importance (Optional)')
# # # # Assuming you have feature importance from your model
# # # # For simplicity, we'll just display a bar chart here.
# # # # Replace this part with actual feature importance logic if your model supports it.
# # # feature_names = ['Air temperature [K]', 'Process temperature [K]', 'Rotational speed [rpm]']
# # # feature_importance = [0.5, 0.3, 0.2]

# # # fig_importance = go.Figure([go.Bar(x=feature_names, y=feature_importance)])
# # # fig_importance.update_layout(title='Feature Importance', xaxis_title='Features', yaxis_title='Importance')
# # # st.plotly_chart(fig_importance)


# # import streamlit as st
# # import pandas as pd
# # import pickle
# # import xgboost as xgb
# # import plotly.graph_objects as go
# # from sklearn.ensemble import IsolationForest

# # # Function to load the XGBoost model
# # @st.cache_data
# # def load_model():
# #     with open('saved_model/xgboost_model.pkl', 'rb') as f:
# #         model = pickle.load(f)
# #     return model

# # # Load model
# # model = load_model()

# # # Function to preprocess the dataset
# # def preprocess_data(df):
# #     # Modify this preprocessing as per your dataset and requirements
# #     df['hour'] = pd.to_datetime(df['timestamp']).dt.hour
# #     df['day_of_week'] = pd.to_datetime(df['timestamp']).dt.dayofweek
# #     sensor_columns = ['Air temperature [K]', 'Process temperature [K]', 'Rotational speed [rpm]', 'Torque [Nm]']
# #     df['Rolling_Mean_Temperature'] = df['Air temperature [K]'].rolling(window=3).mean()
# #     df['Rolling_Std_Temperature'] = df['Air temperature [K]'].rolling(window=3).std()
# #     df['Lag_1_Temperature'] = df['Air temperature [K]'].shift(1)
# #     df['Lag_2_Temperature'] = df['Air temperature [K]'].shift(2)

# #     # Drop rows with NaN values in the necessary columns
# #     df = df.dropna(subset=sensor_columns + ['Rolling_Mean_Temperature', 'Rolling_Std_Temperature', 'Lag_1_Temperature', 'Lag_2_Temperature'])
    
# #     return df, sensor_columns

# # # Function to predict anomalies using XGBoost (or Isolation Forest)
# # def predict_anomalies(df, model, sensor_columns):
# #     # Prepare features for anomaly detection
# #     X = df[sensor_columns + ['Rolling_Mean_Temperature', 'Rolling_Std_Temperature', 'Lag_1_Temperature', 'Lag_2_Temperature']]
    
# #     # If using IsolationForest, predict anomalies
# #     if isinstance(model, IsolationForest):
# #         predictions = model.predict(X)
# #         predictions = [1 if p == -1 else 0 for p in predictions]  # Convert IsolationForest output: -1 for anomaly, 1 for normal
# #     else:
# #         predictions = model.predict(X)
# #         predictions = [1 if p == 1 else 0 for p in predictions]  # Convert XGBoost output to binary: 1 for anomaly, 0 for normal
    
# #     # Display distribution of predictions
# #     st.write("Anomaly prediction distribution:")
# #     st.write(pd.Series(predictions).value_counts())  # Display count of 1s and 0s

# #     return predictions

# # # Load dataset
# # df = pd.read_csv('data/Combined_Dataset.csv')

# # # Preprocess the data
# # df, sensor_columns = preprocess_data(df)

# # # Choose the model for prediction (XGBoost or Isolation Forest)
# # model_type = "XGBoost"  # Change this to "IsolationForest" if you're using IsolationForest for anomaly detection

# # if model_type == "XGBoost":
# #     model = load_model()  # Load XGBoost model
# # elif model_type == "IsolationForest":
# #     # Train Isolation Forest model
# #     isolation_model = IsolationForest(contamination=0.01)  # Adjust contamination as needed
# #     isolation_model.fit(df[sensor_columns + ['Rolling_Mean_Temperature', 'Rolling_Std_Temperature', 'Lag_1_Temperature', 'Lag_2_Temperature']])
# #     model = isolation_model

# # # Predict anomalies using the selected model
# # y_pred = predict_anomalies(df, model, sensor_columns)

# # # Add predictions to the dataframe
# # df['anomaly'] = y_pred

# # # Display the dataframe and anomaly information
# # st.title('Anomaly Detection and Prediction Dashboard')
# # st.write('Dataset Overview:')
# # st.dataframe(df)

# # # Show model performance (you can replace this with accuracy, confusion matrix, etc.)
# # st.subheader('Model Performance (Classification Report)')
# # st.text('Accuracy, Precision, Recall, F1-Score: 0.88 (as an example)')

# # # Plot anomalies over time
# # st.subheader('Anomalies Over Time (Plotly Graph)')
# # fig = go.Figure()
# # fig.add_trace(go.Scatter(x=df['timestamp'], y=df['anomaly'], mode='markers', name='Anomaly'))
# # fig.update_layout(title='Anomalies Over Time', xaxis_title='Timestamp', yaxis_title='Anomaly', showlegend=True)
# # st.plotly_chart(fig)

# import streamlit as st
# import pandas as pd
# import pickle
# import plotly.graph_objects as go
# from sklearn.preprocessing import StandardScaler
# from sklearn.metrics import classification_report
# import xgboost as xgb

# # Function to load the trained Isolation Forest model
# @st.cache_data
# def load_model():
#     with open('saved_model/isolation_forest_model.pkl', 'rb') as f:
#         model = pickle.load(f)
#     return model

# # Load the trained model
# model = load_model()

# # Function to preprocess the dataset
# def preprocess_data(df):
#     df['hour'] = pd.to_datetime(df['timestamp']).dt.hour
#     df['day_of_week'] = pd.to_datetime(df['timestamp']).dt.dayofweek
#     df['Rolling_Mean_Temperature'] = df['Air temperature [K]'].rolling(window=3).mean()
#     df['Rolling_Std_Temperature'] = df['Air temperature [K]'].rolling(window=3).std()
#     df = df.dropna()  # Drop rows with NaN values
#     return df

# # Function to predict anomalies using the Isolation Forest model
# def predict_anomalies(df, model):
#     features = ['Air temperature [K]', 'Process temperature [K]', 'Rotational speed [rpm]', 'Torque [Nm]',
#                 'Rolling_Mean_Temperature', 'Rolling_Std_Temperature', 'hour', 'day_of_week']
    
#     # Standardizing the features
#     X = df[features]
#     scaler = StandardScaler()
#     X_scaled = scaler.fit_transform(X)
    
#     # Predict anomalies using the Isolation Forest model
#     y_pred = model.predict(X_scaled)
    
#     # Convert -1 to 1 (anomaly) and 1 to 0 (normal)
#     y_pred = [1 if x == -1 else 0 for x in y_pred]
    
#     return y_pred

# # Load the dataset
# df = pd.read_csv('data/Combined_Dataset.csv')

# # Preprocess the data
# df = preprocess_data(df)

# # Predict anomalies using the Isolation Forest model
# y_pred = predict_anomalies(df, model)

# # Add anomaly predictions to the dataframe
# df['anomaly'] = y_pred

# # Streamlit Dashboard Layout
# st.title('Anomaly Detection and Prediction Dashboard')

# # Dataset Overview
# st.subheader('Dataset Overview:')
# st.write("This is the preprocessed dataset used for anomaly detection. Below is the data along with the anomaly predictions.")
# st.dataframe(df)

# # Model Performance: Classification Report
# st.subheader('Model Performance (Example - Classification Report)')
# y_test = df['Machine failure']  # Assuming 'Machine failure' is the actual target (replace with your actual test data)
# st.text(classification_report(y_test, y_pred))

# # Anomalies Over Time: Plot anomalies over time
# st.subheader('Anomalies Over Time (Plotly Visualization)')
# fig = go.Figure()
# fig.add_trace(go.Scatter(x=df['timestamp'], y=df['anomaly'], mode='markers', name='Anomaly', marker=dict(color='red')))
# fig.update_layout(title='Anomalies Over Time',
#                   xaxis_title='Timestamp',
#                   yaxis_title='Anomaly (1 = Anomaly, 0 = Normal)',
#                   showlegend=True)
# st.plotly_chart(fig)

# # Sensor Data Analysis: Plot trends of sensor data
# st.subheader('Sensor Data Analysis: Trends of Sensor Data Over Time')
# fig2 = go.Figure()
# fig2.add_trace(go.Scatter(x=df['timestamp'], y=df['Air temperature [K]'], mode='lines', name='Air Temperature [K]'))
# fig2.add_trace(go.Scatter(x=df['timestamp'], y=df['Process temperature [K]'], mode='lines', name='Process Temperature [K]'))
# fig2.add_trace(go.Scatter(x=df['timestamp'], y=df['Rotational speed [rpm]'], mode='lines', name='Rotational Speed [rpm]'))
# fig2.add_trace(go.Scatter(x=df['timestamp'], y=df['Torque [Nm]'], mode='lines', name='Torque [Nm]'))
# fig2.update_layout(title='Sensor Data Trends Over Time',
#                    xaxis_title='Timestamp',
#                    yaxis_title='Sensor Value',
#                    showlegend=True)
# st.plotly_chart(fig2)

# # Anomaly Prediction Results: Display a table with sensor data and its corresponding anomaly prediction
# st.subheader('Anomaly Prediction Results:')
# st.write("Below is a table with sensor data and its corresponding anomaly prediction (1 = Anomaly, 0 = Normal).")
# st.dataframe(df[['timestamp', 'Air temperature [K]', 'Process temperature [K]', 'Rotational speed [rpm]',
#                  'Torque [Nm]', 'anomaly']])

# # Feature Importance (optional): Show the importance of features in anomaly detection (based on XGBoost model)
# st.subheader('Feature Importance (Optional - Based on XGBoost Model):')
# # You need to re-train or load the XGBoost model for feature importance
# xgb_model = xgb.XGBClassifier()
# xgb_model.fit(df[['Air temperature [K]', 'Process temperature [K]', 'Rotational speed [rpm]', 'Torque [Nm]']], df['Machine failure'])
# st.write("Feature importance plot:")
# xgb.plot_importance(xgb_model, importance_type='weight')

import streamlit as st
import pandas as pd
import pickle
import plotly.graph_objects as go
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report
import xgboost as xgb
import matplotlib.pyplot as plt
import seaborn as sns

# Function to load the trained XGBoost model
@st.cache_data
def load_model():
    with open('saved_model/xgboost_model.pkl', 'rb') as f:
        model = pickle.load(f)
    return model

# Load the trained model
model = load_model()

# Function to preprocess the dataset
def preprocess_data(df):
    df['hour'] = pd.to_datetime(df['timestamp']).dt.hour
    df['day_of_week'] = pd.to_datetime(df['timestamp']).dt.dayofweek
    df['Rolling_Mean_Temperature'] = df['Air temperature [K]'].rolling(window=3).mean()
    df['Rolling_Std_Temperature'] = df['Air temperature [K]'].rolling(window=3).std()
    df = df.dropna()  # Drop rows with NaN values
    return df

# Function to predict anomalies using the XGBoost model
def predict_anomalies(df, model):
    features = ['Air temperature [K]', 'Process temperature [K]', 'Rotational speed [rpm]', 'Torque [Nm]',
                'Rolling_Mean_Temperature', 'Rolling_Std_Temperature', 'hour', 'day_of_week']
    
    # Standardizing the features
    X = df[features]
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Predict anomalies using the XGBoost model
    y_pred = model.predict(X_scaled)
    
    # Convert 1 to anomaly and 0 to normal
    return y_pred

# Load the dataset
df = pd.read_csv('data/Combined_Dataset.csv')
print(df.columns)

# Preprocess the data
df = preprocess_data(df)

# Predict anomalies using the XGBoost model
y_pred = predict_anomalies(df, model)

# Add anomaly predictions to the dataframe
df['anomaly'] = y_pred

# Streamlit Dashboard Layout
st.title('Anomaly Detection and Prediction Dashboard')

# Dataset Overview
st.subheader('Dataset Overview:')
st.write("This is the preprocessed dataset used for anomaly detection. Below is the data along with the anomaly predictions.")
st.dataframe(df)

# Model Performance: Classification Report
st.subheader('Model Performance (Example - Classification Report)')
y_test = df['Machine failure']  # Assuming 'Machine failure' is the actual target (replace with your actual test data)
st.text(classification_report(y_test, y_pred))

# Anomalies Over Time: Plot anomalies over time
st.subheader('Anomalies Over Time (Plotly Visualization)')
fig = go.Figure()
fig.add_trace(go.Scatter(x=df['timestamp'], y=df['anomaly'], mode='markers', name='Anomaly', marker=dict(color='red')))
fig.update_layout(title='Anomalies Over Time',
                  xaxis_title='Timestamp',
                  yaxis_title='Anomaly (1 = Anomaly, 0 = Normal)',
                  showlegend=True)
st.plotly_chart(fig)

# Sensor Data Analysis: Plot trends of sensor data
st.subheader('Sensor Data Analysis: Trends of Sensor Data Over Time')
fig2 = go.Figure()
fig2.add_trace(go.Scatter(x=df['timestamp'], y=df['Air temperature [K]'], mode='lines', name='Air Temperature [K]'))
fig2.add_trace(go.Scatter(x=df['timestamp'], y=df['Process temperature [K]'], mode='lines', name='Process Temperature [K]'))
fig2.add_trace(go.Scatter(x=df['timestamp'], y=df['Rotational speed [rpm]'], mode='lines', name='Rotational Speed [rpm]'))
fig2.add_trace(go.Scatter(x=df['timestamp'], y=df['Torque [Nm]'], mode='lines', name='Torque [Nm]'))
fig2.update_layout(title='Sensor Data Trends Over Time',
                   xaxis_title='Timestamp',
                   yaxis_title='Sensor Value',
                   showlegend=True)
st.plotly_chart(fig2)

# Anomaly Prediction Results: Display a table with sensor data and its corresponding anomaly prediction
st.subheader('Anomaly Prediction Results:')
st.write("Below is a table with sensor data and its corresponding anomaly prediction (1 = Anomaly, 0 = Normal).")
st.dataframe(df[['timestamp', 'Air temperature [K]', 'Process temperature [K]', 'Rotational speed [rpm]',
                 'Torque [Nm]', 'anomaly']])

# Feature Importance (Optional - Based on XGBoost Model):
st.subheader('Feature Importance (Optional - Based on XGBoost Model):')

# Clean column names by removing special characters
df.columns = [col.replace('[', '').replace(']', '').replace('<', '').replace('>', '') for col in df.columns]

# Prepare the features and target
features = ['Air temperature [K]', 'Process temperature [K]', 'Rotational speed [rpm]', 'Torque [Nm]',
            'Rolling_Mean_Temperature', 'Rolling_Std_Temperature', 'hour', 'day_of_week']

X = df[features]
y = df['Machine failure']

# Initialize the XGBoost model
xgb_model = xgb.XGBClassifier(eval_metric='logloss')

# Train the model
xgb_model.fit(X, y)


st.subheader("Confusion Matrix")

# Compute Confusion Matrix
confusion_matrix = pd.crosstab(y_test, y_pred, rownames=['Actual'], colnames=['Predicted'])

# Debugging Step: Print Confusion Matrix
st.write(confusion_matrix)

# Ensure columns and index are strings
confusion_matrix.columns = confusion_matrix.columns.astype(str)
confusion_matrix.index = confusion_matrix.index.astype(str)

# Create Heatmap
fig = go.Figure(data=[
    go.Heatmap(
        z=confusion_matrix.values,
        x=confusion_matrix.columns,
        y=confusion_matrix.index,
        colorscale='Viridis',
        zmid=0,
    )
])

# Layout
fig.update_layout(
    title="Confusion Matrix",
    xaxis_title="Predicted",
    yaxis_title="Actual"
)

# Display in Streamlit
st.plotly_chart(fig)
#Optional: Feature Importance (if available from the model)
st.subheader('Feature Importance (Optional)')
# # # # Assuming you have feature importance from your model
# # # # For simplicity, we'll just display a bar chart here.
# # # # Replace this part with actual feature importance logic if your model supports it.
feature_names = ['Air temperature [K]', 'Process temperature [K]', 'Rotational speed [rpm]']
feature_importance = [0.5, 0.3, 0.2]

fig_importance = go.Figure([go.Bar(x=feature_names, y=feature_importance)])
fig_importance.update_layout(title='Feature Importance', xaxis_title='Features', yaxis_title='Importance')
st.plotly_chart(fig_importance)