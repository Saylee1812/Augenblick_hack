

# import pandas as pd
# from sklearn.ensemble import IsolationForest
# from sklearn.model_selection import train_test_split
# from sklearn.preprocessing import StandardScaler
# import pickle

# # Load dataset
# df = pd.read_csv('data/Combined_Dataset.csv')

# # Preprocess the dataset (this can be customized as per your dataset and needs)
# def preprocess_data(df):
#     df['hour'] = pd.to_datetime(df['timestamp']).dt.hour
#     df['day_of_week'] = pd.to_datetime(df['timestamp']).dt.dayofweek
#     df['Rolling_Mean_Temperature'] = df['Air temperature [K]'].rolling(window=3).mean()
#     df['Rolling_Std_Temperature'] = df['Air temperature [K]'].rolling(window=3).std()
#     df = df.dropna()  # Drop rows with NaN values
#     return df

# df = preprocess_data(df)

# # Define your features and target variable (assuming 'Machine failure' is your label for anomalies)
# features = ['Air temperature [K]', 'Process temperature [K]', 'Rotational speed [rpm]', 'Torque [Nm]',
#             'Rolling_Mean_Temperature', 'Rolling_Std_Temperature', 'hour', 'day_of_week']
# X = df[features]

# # Standardize the features
# scaler = StandardScaler()
# X_scaled = scaler.fit_transform(X)

# # Initialize and train the Isolation Forest model
# model = IsolationForest(contamination=0.05)  # Adjust contamination as needed
# model.fit(X_scaled)

# # Save the trained model
# with open('saved_model/isolation_forest_model.pkl', 'wb') as f:
#     pickle.dump(model, f)

# # Predict anomalies
# y_pred = model.predict(X_scaled)

# # Convert predictions to 0 for normal, 1 for anomaly
# y_pred = [1 if x == -1 else 0 for x in y_pred]

# # Print the number of anomalies detected
# print(f"Number of anomalies detected: {y_pred.count(1)}")
import pandas as pd
import xgboost as xgb
import pickle
from sklearn.ensemble import IsolationForest
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report

# Load dataset
df = pd.read_csv('data/Combined_Dataset.csv')

# Preprocess the dataset
def preprocess_data(df):
    if 'timestamp' in df.columns:
        df['hour'] = pd.to_datetime(df['timestamp']).dt.hour
        df['day_of_week'] = pd.to_datetime(df['timestamp']).dt.dayofweek
    else:
        print("Warning: 'timestamp' column not found in dataset.")

    df['Rolling_Mean_Temperature'] = df['Air temperature [K]'].rolling(window=3).mean()
    df['Rolling_Std_Temperature'] = df['Air temperature [K]'].rolling(window=3).std()
    
    df = df.dropna()  # Drop rows with NaN values
    return df

df = preprocess_data(df)

# Define features
features = ['Air temperature [K]', 'Process temperature [K]', 'Rotational speed [rpm]', 'Torque [Nm]', 
            'Rolling_Mean_Temperature', 'Rolling_Std_Temperature', 'hour', 'day_of_week']
X = df[features]

# Standardize the features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Save the scaler for future use
with open('saved_model/scaler.pkl', 'wb') as f:
    pickle.dump(scaler, f)

### **Option 1: Supervised Learning - XGBoost Classifier**
if 'Machine failure' in df.columns:
    y = df['Machine failure']  # Assuming 1 for failure (anomaly) and 0 for normal

    # Split data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

    # Train XGBoost model
    xgb_model = xgb.XGBClassifier(eval_metric='logloss')
    xgb_model.fit(X_train, y_train)

    # Save the trained model
    with open('saved_model/xgboost_model.pkl', 'wb') as f:
        pickle.dump(xgb_model, f)

    # Evaluate the model
    y_pred = xgb_model.predict(X_test)
    print("\nXGBoost Classification Report:")
    print(classification_report(y_test, y_pred))

else:
    print("Warning: 'Machine failure' column not found, skipping XGBoost training.")

### **Option 2: Unsupervised Learning - Isolation Forest**
# Train Isolation Forest model
iso_forest_model = IsolationForest(contamination=0.05, random_state=42)  # Adjust contamination if needed
iso_forest_model.fit(X_scaled)

# Save the trained model
with open('saved_model/isolation_forest_model.pkl', 'wb') as f:
    pickle.dump(iso_forest_model, f)

# Predict anomalies
y_pred_iso = iso_forest_model.predict(X_scaled)

# Convert -1 (anomaly) to 1 and 1 (normal) to 0
y_pred_iso = [1 if x == -1 else 0 for x in y_pred_iso]

# Print anomaly detection results
print(f"\nNumber of anomalies detected by Isolation Forest: {y_pred_iso.count(1)}")
